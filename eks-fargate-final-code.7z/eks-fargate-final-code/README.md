# Source code of AWS EKS with fargate cluster setup.

